#!/system/bin/sh

STAT=`cat /system/etc/install-recovery.sh | grep busybox`;

if [ ! $STAT  ]
then
  echo "" >> /system/etc/install-recovery.sh;
  echo "###### Bootstrapper ######" >> /system/etc/install-recovery.sh;
  echo "busybox run-parts /system/etc/init.d" >> /system/etc/install-recovery.sh;
fi
