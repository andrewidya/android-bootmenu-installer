#!/sbin/sh

######## BootMenu Script
######## Execute [2nd-init] Menu


export PATH=/sbin:/system/xbin:/system/bin
source /system/bootmenu/script/_config.sh
######## Main Script

mount -o remount,rw /
rm -R /system/etc/init.d/97bootmenu
rm -f /*.rc
rm -f /*.sh
cp -r -f /system/bootmenu/2nd-init/* /
chmod 755 /*.rc
chmod 4755 /system/bootmenu/binary/2nd-init

## unmount devices
sync
umount /dev/cpuctl
umount /dev/pts
umount /cache
umount /data

## /tmp folder can be a link to /data/tmp, bad thing !
umount -l /tmp
rm /tmp
mkdir -p /tmp
mkdir -p /res

rm -f /etc
mkdir /etc

rm -f /sdcard
mkdir /sdcard

chmod 755 /sbin
chmod 755 /res

cp -r -f $BM_ROOTDIR/recovery/res/* /res/
cp -p -f $BM_ROOTDIR/recovery/sbin/* /sbin/
cp -p -f $BM_ROOTDIR/script/recoveryexit.sh /sbin/

cd /sbin
ln -s recovery edify
ln -s recovery setprop
ln -s recovery dump_image
ln -s recovery erase_image
ln -s recovery flash_image
ln -s recovery mkyaffs2image
ln -s recovery unyaffs
ln -s recovery nandroid
ln -s recovery volume
ln -s recovery reboot

chmod +rx /sbin/*

rm -f /sbin/postrecoveryboot.sh

if [ ! -e /etc/recovery.fstab ]; then
    cp $BM_ROOTDIR/recovery/recovery.fstab /etc/recovery.fstab
fi

mkdir -p /cache/recovery
touch /cache/recovery/command
touch /cache/recovery/log
touch /cache/recovery/last_log
touch /tmp/recovery.log

killall adbd

ps | grep -v grep | grep adbd
ret=$?

if [ ! $ret -eq 0 ]; then
   # $BM_ROOTDIR/script/adbd.sh

   # don't use adbd here, will load many android process which locks /system
   killall adbd
   killall adbd.root
fi

umount /system

usleep 50000

######## Cleanup

## reduce lcd backlight to save battery
echo 10 > /sys/class/leds/lcd-backlight/brightness


######## Let's go

/system/bootmenu/binary/2nd-init

